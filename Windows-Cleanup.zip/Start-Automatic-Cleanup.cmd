@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Clean-Windows.ps1" -Automatic
echo.
pause
