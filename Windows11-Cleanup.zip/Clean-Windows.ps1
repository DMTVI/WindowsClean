﻿#Requires -Version 5.1
[CmdletBinding()]
param([switch]$Automatic)
$ErrorActionPreference = 'Stop'
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $launchArgs = '-NoProfile -ExecutionPolicy Bypass -File "{0}"' -f $PSCommandPath
    if ($Automatic) { $launchArgs += ' -Automatic' }
    try {
        $child = Start-Process "$PSHOME\powershell.exe" -Verb RunAs -ArgumentList $launchArgs -Wait -PassThru
        exit $child.ExitCode
    } catch { Write-Host 'Запуск отменён или нет прав администратора.'; exit 1 }
}
$script:Problems = New-Object 'System.Collections.Generic.List[string]'
$drive = $env:SystemDrive
$log = Join-Path $PSScriptRoot ('Cleanup-{0}.log' -f (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
$logging = $false
$script:RestartNeeded = $false
$exitCode = 0
function Confirm-Action([string]$Message) {
    Write-Host $Message -ForegroundColor Yellow
    return ((Read-Host 'Для продолжения введите ДА') -ceq 'ДА')
}
function Invoke-Tool([string]$Name, [string]$File, [string[]]$ToolArgs, [switch]$Window) {
    Write-Host "`n$Name" -ForegroundColor Cyan
    $path = Join-Path "$env:SystemRoot\System32" $File
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Не найдено: $path" }
    if ($Window) {
        if ($ToolArgs.Count) { $p = Start-Process $path -ArgumentList $ToolArgs -Wait -PassThru }
        else { $p = Start-Process $path -Wait -PassThru }
        $code = $p.ExitCode
    } else { & $path @ToolArgs; $code = $LASTEXITCODE }
    if ($code -eq 3010) { $script:RestartNeeded = $true }
    elseif ($code -ne 0) { throw "$Name : код завершения $code" }
}
function Invoke-Step([scriptblock]$Action) {
    try { & $Action } catch { $script:Problems.Add($_.Exception.Message); Write-Warning $_.Exception.Message }
}
function Get-FreeSpace {
    $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$drive'"
    if (-not $disk) { throw 'Не удалось определить свободное место.' }
    return [double]$disk.FreeSpace
}
function Invoke-Temp([switch]$Preview) {
    $cutoff = (Get-Date).AddDays(-7)
    $count = 0; $skipped = 0; $scanErrors = 0; [long]$bytes = 0
    # Fixed allowlist; no recursive deletion or traversal of reparse points.
    $roots = @((Join-Path $env:USERPROFILE 'AppData\Local\Temp'), (Join-Path $env:SystemRoot 'Temp')) | Select-Object -Unique
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root -PathType Container)) { continue }
        $rootItem = Get-Item -LiteralPath $root -Force
        if ($rootItem.Attributes -band [IO.FileAttributes]::ReparsePoint) { Write-Warning "Папка-ссылка пропущена: $root"; continue }
        $prefix = [IO.Path]::GetFullPath($root).TrimEnd('\') + '\'
        Write-Host "`nTemp: $root" -ForegroundColor Cyan
        $pending = New-Object 'System.Collections.Generic.Stack[string]'
        $pending.Push($rootItem.FullName)
        while ($pending.Count -gt 0) {
            $folder = $pending.Pop()
            try { $current = Get-Item -LiteralPath $folder -Force } catch { $scanErrors++; continue }
            if ($current.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
            $readErrors = @()
            $items = @(Get-ChildItem -LiteralPath $folder -Force -ErrorAction SilentlyContinue -ErrorVariable readErrors)
            $scanErrors += $readErrors.Count
            foreach ($item in $items) {
                $full = [IO.Path]::GetFullPath($item.FullName)
                if (-not $full.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { continue }
                if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
                if ($item.PSIsContainer) { $pending.Push($full); continue }
                if ($item.LastWriteTime -ge $cutoff -or $item.CreationTime -ge $cutoff) { continue }
                if ($Preview) { $count++; $bytes += $item.Length; continue }
                try {
                    $fresh = Get-Item -LiteralPath $full -Force
                    if ($fresh.PSIsContainer -or ($fresh.Attributes -band [IO.FileAttributes]::ReparsePoint)) { continue }
                    if ($fresh.LastWriteTime -ge $cutoff -or $fresh.CreationTime -ge $cutoff) { continue }
                    $length = $fresh.Length
                    Remove-Item -LiteralPath $full -Force -ErrorAction Stop
                    $count++; $bytes += $length
                } catch { $skipped++ }
            }
        }
    }
    $label = if ($Preview) { 'Подходят для удаления' } else { 'Удалено' }
    Write-Host ('{0}: {1} файлов ({2:N2} МБ). Занятых/недоступных: {3}. Ошибок чтения папок: {4}.' -f $label,$count,($bytes/1MB),$skipped,$scanErrors)
    Write-Host 'Проверяются даты создания и изменения: старше 7 дней. Пустые папки остаются.'
}
function Invoke-Components {
    Invoke-Tool 'Очистка компонентов Windows' 'Dism.exe' @('/Online','/Cleanup-Image','/StartComponentCleanup','/NoRestart')
}
function Invoke-Optimize {
    Invoke-Tool 'Оптимизация системного диска с учётом SSD/HDD' 'defrag.exe' @($drive,'/O','/U','/V')
}
function Invoke-RestoreMenu([switch]$Delete) {
    # Preflight only: never enable services or treat unavailable restore data as empty.
    try {
        foreach ($serviceName in @('winmgmt','VSS')) {
            $service = Get-Service -Name $serviceName -ErrorAction Stop
            if ([string]$service.StartType -eq 'Disabled') {
                throw ('Служба {0} ({1}) отключена.' -f $service.Name,$service.DisplayName)
            }
        }
        $null = @(Get-RestoreInventory)
    } catch {
        Write-Warning 'Точки восстановления сейчас недоступны. Операция пропущена; удаление не запускалось.'
        Write-Host ('Причина: {0}' -f $_.Exception.Message)
        Write-Host 'Это не означает отсутствия точек. Проверьте «Защиту системы»: Win+R -> SystemPropertiesProtection.'
        Write-Host 'Скрипт не включает службы и не меняет защиту системы. Другие пункты можно использовать отдельно.'
        return
    }
    # Failures during actual deletion must still reach the main error handler.
    if ($Delete) { Invoke-RestoreCleanup } else { Show-RestoreInventory }
}

function Get-RestoreInventory {
    # CreationTime is the WMI datetime string returned by this Windows cmdlet.
    @(Get-ComputerRestorePoint -ErrorAction Stop | Sort-Object -Property @{Expression={[Management.ManagementDateTimeConverter]::ToDateTime($_.CreationTime)}}, SequenceNumber -Descending)
}
function Show-RestoreInventory {
    $points = @(Get-RestoreInventory)
    if ($points.Count -eq 0) { Write-Host 'Точки восстановления не найдены.'; return }
    $points | Select-Object SequenceNumber, @{Name='Дата';Expression={[Management.ManagementDateTimeConverter]::ToDateTime($_.CreationTime)}}, Description | Format-Table -AutoSize | Out-Host
    Write-Host ('Самая последняя точка: №{0}.' -f $points[0].SequenceNumber)
}
function Remove-RestorePointById([uint32]$SequenceNumber) {
    # Resolve the documented System Restore API at runtime, per Microsoft guidance.
    if (-not ('CleanupRestore.Native' -as [type])) {
        Add-Type -TypeDefinition @"
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
namespace CleanupRestore {
    public static class Native {
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        private static extern IntPtr LoadLibraryW(string path);
        [DllImport("kernel32.dll", CharSet=CharSet.Ansi, ExactSpelling=true, SetLastError=true)]
        private static extern IntPtr GetProcAddress(IntPtr module, string name);
        [DllImport("kernel32.dll")]
        private static extern bool FreeLibrary(IntPtr module);
        [UnmanagedFunctionPointer(CallingConvention.Winapi)]
        private delegate uint RemovePoint(uint sequence);
        public static uint Remove(uint sequence) {
            IntPtr module = LoadLibraryW(System.IO.Path.Combine(Environment.SystemDirectory, "SrClient.dll"));
            if (module == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
            try {
                IntPtr address = GetProcAddress(module, "SRRemoveRestorePoint");
                if (address == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
                RemovePoint remove = (RemovePoint)Marshal.GetDelegateForFunctionPointer(address, typeof(RemovePoint));
                return remove(sequence);
            } finally { FreeLibrary(module); }
        }
    }
}
"@
    }
    $code = [CleanupRestore.Native]::Remove($SequenceNumber)
    if ($code -ne 0) { throw "Не удалось удалить точку №$SequenceNumber. Код Windows: $code. Дальнейшее удаление остановлено." }
}
function Invoke-RestoreCleanup {
    $points = @(Get-RestoreInventory)
    if ($points.Count -le 1) {
        Write-Host ('Найдено точек: {0}. Удалять нечего; изменений нет.' -f $points.Count)
        return
    }
    $keep = $points[0]
    $targets = @($points | Select-Object -Skip 1)
    Write-Host ('Будет сохранена последняя точка №{0}: {1} ({2}).' -f $keep.SequenceNumber, $keep.Description, $keep.CreationTime) -ForegroundColor Green
    Write-Host 'К удалению:' -ForegroundColor Yellow
    $targets | Select-Object SequenceNumber, CreationTime, Description | Format-Table -AutoSize | Out-Host
    if (-not (Confirm-Action 'Все перечисленные старые точки будут удалены без возможности отмены. Откат к ним станет недоступен. Последняя точка не проверялась на работоспособность.')) {
        Write-Host 'Удаление отменено.'; return
    }
    $deleted = 0
    foreach ($point in $targets) {
        $current = @(Get-RestoreInventory)
        if (-not ($current | Where-Object { $_.SequenceNumber -eq $keep.SequenceNumber })) {
            throw 'Сохраняемая точка исчезла. Дальнейшее удаление остановлено.'
        }
        if ($point.SequenceNumber -eq $keep.SequenceNumber) { throw 'Защита последней точки: удаление остановлено.' }
        if (-not ($current | Where-Object { $_.SequenceNumber -eq $point.SequenceNumber })) {
            Write-Host ('Точка №{0} уже отсутствует; пропуск.' -f $point.SequenceNumber); continue
        }
        Remove-RestorePointById -SequenceNumber ([uint32]$point.SequenceNumber)
        $remaining = @(Get-RestoreInventory)
        if (-not ($remaining | Where-Object { $_.SequenceNumber -eq $keep.SequenceNumber })) {
            throw 'После операции сохраняемая точка не найдена. Дальнейшее удаление остановлено.'
        }
        if ($remaining | Where-Object { $_.SequenceNumber -eq $point.SequenceNumber }) {
            throw ('Windows ещё показывает точку №{0}. Дальнейшее удаление остановлено; проверьте список повторно.' -f $point.SequenceNumber)
        }
        $deleted++
        Write-Host ('Удалена точка №{0}.' -f $point.SequenceNumber)
    }
    Write-Host ('Удалено точек: {0}. Сохранена точка №{1}. Новые точки, появившиеся во время операции, не удаляются.' -f $deleted,$keep.SequenceNumber)
    Write-Host 'Объём освобождённого места зависит от хранения общих данных Windows.'
}

function Invoke-Standard {
    Write-Host 'Temp старше 7 дней + очистка компонентов + оптимизация диска.'
    Write-Host 'Документы, Загрузки, корзина и браузеры не очищаются.'
    $before = Get-FreeSpace
    Invoke-Step { Invoke-Temp }
    Invoke-Step { Invoke-Components }
    Invoke-Step { Invoke-Optimize }
    $after = Get-FreeSpace
    Write-Host ('Свободно до: {0:N2} ГБ; после: {1:N2} ГБ; изменение: {2:N2} ГБ.' -f ($before/1GB),($after/1GB),(($after-$before)/1GB))
    Write-Host 'Параллельная работа Windows может влиять на изменение места.'
}
try {
    Start-Transcript -Path $log | Out-Null
    $logging = $true
    Write-Host 'ОЧИСТКА WINDOWS 10/11 — by DMTVI' -ForegroundColor Green
    Write-Host "Пользователь: $env:USERNAME. Системный диск: $drive"
    Write-Host 'Закройте приложения, подключите питание. Не запускайте во время установки обновлений.'
    if ($Automatic) { Invoke-Standard }
    else {
        :menu while ($true) {
            Write-Host @"

 1  Стандартная очистка автоматически (Temp + DISM + оптимизация)
 2  Предварительный подсчёт старых файлов Temp, без удаления
 3  Только очистка старых файлов Temp
 4  Cleanmgr: открыть выбор категорий системного диска
 5  Cleanmgr: настроить сохраняемый набор 27183
 6  Cleanmgr: выполнить набор 27183 на подходящих дисках
 7  DISM: анализ компонентов, без очистки
 8  DISM: обычная очистка компонентов
 9  Оптимизировать системный диск (SSD/HDD)
10  Очистить корзину текущего пользователя на системном диске
11  Сбросить кэш Microsoft Store
12  Очистить кэш DNS
13  Открыть настройки «Память» и «Контроль памяти»
14  Отключить гибернацию и быстрый запуск, удалить hiberfil.sys
15  Включить гибернацию обратно
16  DISM /ResetBase: очистка с потерей возможности удаления обновлений
17  Удалить старые точки восстановления, сохранив последнюю
18  Показать точки восстановления без удаления
 0  Выход
"@
            $choice = Read-Host 'Выберите пункт'
            if ($choice -eq '0') { break menu }
            Invoke-Step {
                switch ($choice) {
                    '1' { Invoke-Standard }
                    '2' { Invoke-Temp -Preview }
                    '3' { Invoke-Temp }
                    '4' { Invoke-Tool 'Выберите категории в окне Windows' 'cleanmgr.exe' @('/d',$drive) -Window }
                    '5' {
                        Write-Host 'Набор 27183: существующие настройки этого номера будут изменены.'
                        Write-Host 'Выбранные категории затем будут очищаться на всех подходящих дисках.'
                        Invoke-Tool 'Настройка cleanmgr' 'cleanmgr.exe' @('/sageset:27183') -Window
                    }
                    '6' {
                        if (Confirm-Action 'Сначала настройте набор в пункте 5. Будут удалены выбранные категории на всех подходящих дисках, включая корзину, если она выбрана.') {
                            Invoke-Tool 'Сохранённый набор cleanmgr' 'cleanmgr.exe' @('/sagerun:27183') -Window
                        }
                    }
                    '7' { Invoke-Tool 'Анализ компонентов' 'Dism.exe' @('/Online','/Cleanup-Image','/AnalyzeComponentStore') }
                    '8' { Invoke-Components }
                    '9' { Invoke-Optimize }
                    '10' {
                        if (Confirm-Action "Корзина текущего пользователя на $drive будет очищена. Восстановление через корзину станет невозможно.") {
                            Clear-RecycleBin -DriveLetter $drive.TrimEnd(':') -Force -ErrorAction Stop
                            Write-Host 'Корзина очищена.'
                        }
                    }
                    '11' { Invoke-Tool 'Сброс кэша Microsoft Store' 'wsreset.exe' @() -Window }
                    '12' { Invoke-Tool 'Очистка DNS; место на диске практически не освобождает' 'ipconfig.exe' @('/flushdns') }
                    '13' { Start-Process 'ms-settings:storagesense' | Out-Null }
                    '14' {
                        if (Confirm-Action 'Отключатся гибернация и быстрый запуск. На ноутбуке это может повлиять на поведение при низком заряде.') {
                            Invoke-Tool 'Отключение гибернации' 'powercfg.exe' @('/hibernate','off')
                        }
                    }
                    '15' { Invoke-Tool 'Включение гибернации, если она поддерживается' 'powercfg.exe' @('/hibernate','on') }
                    '16' {
                        if (Confirm-Action 'После /ResetBase установленные обновления нельзя будет удалить. Для обычной очистки используйте пункт 8.') {
                            Invoke-Tool 'Глубокая очистка компонентов' 'Dism.exe' @('/Online','/Cleanup-Image','/StartComponentCleanup','/ResetBase','/NoRestart')
                        }
                    }
                    '17' { Invoke-RestoreMenu -Delete }
                    '18' { Invoke-RestoreMenu }
                    default { Write-Host 'Нет такого пункта.' }
                }
            }
        }
    }
} catch { $script:Problems.Add($_.Exception.Message); Write-Warning $_.Exception.Message }
finally {
    if ($script:Problems.Count) {
        $exitCode = 1
        Write-Host 'Есть ошибки, смотрите журнал:' -ForegroundColor Yellow
        $script:Problems | ForEach-Object { Write-Host " - $_" }
    } else { Write-Host 'Работа завершена без зарегистрированных ошибок.' -ForegroundColor Green }
    if ($script:RestartNeeded) { Write-Host 'Windows запросила перезагрузку. Перезагрузите компьютер самостоятельно.' }
    Write-Host "Журнал: $log"
    if ($logging) { Stop-Transcript | Out-Null }
    if (-not $Automatic) { Read-Host 'Нажмите Enter для закрытия' | Out-Null }
}
exit $exitCode
